-- phpMyAdmin SQL Dump
-- version 4.3.12
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 19, 2015 alle 10:13
-- Versione del server: 5.6.22-log
-- PHP Version: 5.6.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbveicoli`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `alimentazione`
--

CREATE TABLE IF NOT EXISTS `alimentazione` (
  `codAlimentazione` int(10) NOT NULL,
  `tipoAlimentazione` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `alimentazione`
--

INSERT INTO `alimentazione` (`codAlimentazione`, `tipoAlimentazione`) VALUES
(1, 'Diesel'),
(2, 'Benzina'),
(3, 'Metano'),
(4, 'Gpl'),
(5, 'Elettrico'),
(6, 'Ibrido'),
(7, 'Idrogeno');

-- --------------------------------------------------------

--
-- Struttura della tabella `automobile`
--

CREATE TABLE IF NOT EXISTS `automobile` (
  `targa` varchar(8) NOT NULL,
  `telaio` int(10) unsigned zerofill NOT NULL,
  `marca` varchar(20) NOT NULL,
  `modello` varchar(20) NOT NULL,
  `motore` varchar(20) NOT NULL,
  `immatricolazione` year(4) NOT NULL,
  `velocitàMax` varchar(5) NOT NULL,
  `codAlimentazione` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `automobile`
--

INSERT INTO `automobile` (`targa`, `telaio`, `marca`, `modello`, `motore`, `immatricolazione`, `velocitàMax`, `codAlimentazione`) VALUES
('fgh502mt', 0000000002, 'Fiat', '500', '1.4 16V Matt Black', 2011, '176', 2),
('wt9003hg', 0000000007, 'Renault', 'Clio', '1.5 ', 2009, '180', 3),
('ygb349nb', 0000000001, 'Fiat', 'Punto', '1.3 16V Dynamic', 2009, '150', 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `bicicletta`
--

CREATE TABLE IF NOT EXISTS `bicicletta` (
  `telaio` int(10) unsigned zerofill NOT NULL,
  `tipobici` enum('Sport','Passeggiata','Lavoro') NOT NULL,
  `marca` varchar(20) NOT NULL,
  `modello` varchar(20) NOT NULL,
  `numPosti` enum('1','2','3','4') NOT NULL,
  `materiale` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `bicicletta`
--

INSERT INTO `bicicletta` (`telaio`, `tipobici`, `marca`, `modello`, `numPosti`, `materiale`) VALUES
(0000000004, 'Sport', 'Bianchi', 'Campagnolo Record ', '1', 'Alluminio'),
(0000000005, 'Passeggiata', 'Girardengo', 'City Bike', '1', 'Acciaio'),
(0000000009, 'Lavoro', 'Atala', 'S300', '1', 'Carbonio');

-- --------------------------------------------------------

--
-- Struttura della tabella `catveicolo`
--

CREATE TABLE IF NOT EXISTS `catveicolo` (
  `codVeicolo` int(10) NOT NULL,
  `catVeicolo` varchar(25) NOT NULL,
  `tipoVeicolo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `catveicolo`
--

INSERT INTO `catveicolo` (`codVeicolo`, `catVeicolo`, `tipoVeicolo`) VALUES
(1, 'Autoveicoli', 'Automobile'),
(2, 'Motoveicoli', 'Motocicletta'),
(3, 'Veicoli senza motore', 'Bicicletta'),
(4, 'Autoveicoli', 'Autobus'),
(5, 'Autoveicoli', 'Autocaravan'),
(6, 'Motoveicoli', 'Motocicli 3 ruote'),
(7, 'Motoveicoli', 'Quadricicli'),
(8, 'Veicoli senza motore', 'Carrozza'),
(9, 'Veicoli senza motore', 'Slitta'),
(10, 'Veicoli senza motore', 'Tandem');

-- --------------------------------------------------------

--
-- Struttura della tabella `motocicletta`
--

CREATE TABLE IF NOT EXISTS `motocicletta` (
  `targa` varchar(8) NOT NULL,
  `telaio` int(10) unsigned zerofill NOT NULL,
  `marca` varchar(20) NOT NULL,
  `modello` varchar(20) NOT NULL,
  `motore` varchar(20) NOT NULL,
  `numRuote` enum('2','3','4','5') NOT NULL,
  `immatricolazione` year(4) NOT NULL,
  `velocitaMax` varchar(10) NOT NULL,
  `codAlimentazione` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `motocicletta`
--

INSERT INTO `motocicletta` (`targa`, `telaio`, `marca`, `modello`, `motore`, `numRuote`, `immatricolazione`, `velocitaMax`, `codAlimentazione`) VALUES
('aep104tb', 0000000003, 'Kawasaky', 'Ninja 250R', '250', '2', 2008, '160', 2),
('cx3576kg', 0000000008, 'Suzuki', 'nc 300', '500', '2', 2001, '130', 2),
('zm0923tk', 0000000006, 'Ducati', 'monster 821', '820', '2', 2014, '190', 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `proprieta`
--

CREATE TABLE IF NOT EXISTS `proprieta` (
  `idProprietario` int(10) NOT NULL,
  `telaio` int(10) unsigned zerofill NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `proprieta`
--

INSERT INTO `proprieta` (`idProprietario`, `telaio`) VALUES
(1, 0000000001),
(2, 0000000002),
(3, 0000000003),
(4, 0000000004),
(5, 0000000005),
(6, 0000000006),
(1, 0000000007),
(2, 0000000008),
(1, 0000000009),
(7, 0000000010),
(8, 0000000011),
(10, 0000000011),
(9, 0000000013),
(9, 0000000014);

-- --------------------------------------------------------

--
-- Struttura della tabella `proprietario`
--

CREATE TABLE IF NOT EXISTS `proprietario` (
  `idProprietario` int(10) NOT NULL,
  `nome` varchar(30) NOT NULL,
  `cognome` varchar(30) NOT NULL,
  `indirizzo` varchar(50) NOT NULL,
  `citta` varchar(30) NOT NULL,
  `email` varchar(45) NOT NULL,
  `telefono` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `proprietario`
--

INSERT INTO `proprietario` (`idProprietario`, `nome`, `cognome`, `indirizzo`, `citta`, `email`, `telefono`) VALUES
(1, 'Mario', 'Rossi', 'via caligola 23 ', 'Roma', 'mariorossi@gmail.com', '0923743385'),
(2, 'Maria', 'Gialli', 'via volta 36 ', 'Como', 'mariarossi@yahoo.com', '3889092311'),
(3, 'Angelo', 'Bianchi', 'via varese 57 ', 'Torino', 'angelobianchi@libero.it', '0802336431'),
(4, 'Marcello', 'Neri', 'via salieri 80', 'Monza', 'marcelloneri@gmail.com', '9001232342');

-- --------------------------------------------------------

--
-- Struttura della tabella `veicolo`
--

CREATE TABLE IF NOT EXISTS `veicolo` (
  `telaio` int(10) unsigned zerofill NOT NULL,
  `codveicolo` int(10) NOT NULL,
  `dimensioni` varchar(40) NOT NULL,
  `colore` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `veicolo`
--

INSERT INTO `veicolo` (`telaio`, `codveicolo`, `dimensioni`, `colore`) VALUES
(0000000001, 1, '406x169x149', 'grigio perla'),
(0000000002, 1, '355x163x149', 'verde'),
(0000000003, 2, '208x71x115', 'verde marino'),
(0000000004, 3, '120x75', 'nero'),
(0000000005, 3, '140x60', 'marrone'),
(0000000006, 2, '217x78x80', 'rosso cardinale'),
(0000000007, 1, '438x183x163', 'celeste'),
(0000000008, 2, '220x80x120', 'azzurro'),
(0000000009, 3, '110x95', 'giallo ocra'),
(0000000010, 1, '380x200x180', 'bianco'),
(0000000011, 1, '380x200x180', 'argento'),
(0000000012, 2, '220x80x125', 'nero'),
(0000000013, 3, '130x75', 'rosa'),
(0000000014, 3, '130x80', 'rosso porpora');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alimentazione`
--
ALTER TABLE `alimentazione`
  ADD PRIMARY KEY (`codAlimentazione`);

--
-- Indexes for table `automobile`
--
ALTER TABLE `automobile`
  ADD PRIMARY KEY (`targa`), ADD UNIQUE KEY `codAlimentazione` (`codAlimentazione`), ADD UNIQUE KEY `telaio` (`telaio`);

--
-- Indexes for table `bicicletta`
--
ALTER TABLE `bicicletta`
  ADD UNIQUE KEY `telaio` (`telaio`);

--
-- Indexes for table `catveicolo`
--
ALTER TABLE `catveicolo`
  ADD PRIMARY KEY (`codVeicolo`), ADD KEY `catVeicolo` (`catVeicolo`);

--
-- Indexes for table `motocicletta`
--
ALTER TABLE `motocicletta`
  ADD PRIMARY KEY (`targa`), ADD UNIQUE KEY `telaio` (`telaio`), ADD KEY `codAlimentazione` (`codAlimentazione`);

--
-- Indexes for table `proprieta`
--
ALTER TABLE `proprieta`
  ADD KEY `idProprietario` (`idProprietario`), ADD KEY `telaio` (`telaio`);

--
-- Indexes for table `proprietario`
--
ALTER TABLE `proprietario`
  ADD PRIMARY KEY (`idProprietario`);

--
-- Indexes for table `veicolo`
--
ALTER TABLE `veicolo`
  ADD PRIMARY KEY (`telaio`), ADD KEY `codveicolo` (`codveicolo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `proprietario`
--
ALTER TABLE `proprietario`
  MODIFY `idProprietario` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `veicolo`
--
ALTER TABLE `veicolo`
  MODIFY `telaio` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `automobile`
--
ALTER TABLE `automobile`
ADD CONSTRAINT `automobile_ibfk_2` FOREIGN KEY (`codAlimentazione`) REFERENCES `alimentazione` (`codAlimentazione`),
ADD CONSTRAINT `automobile_ibfk_3` FOREIGN KEY (`telaio`) REFERENCES `veicolo` (`telaio`);

--
-- Limiti per la tabella `bicicletta`
--
ALTER TABLE `bicicletta`
ADD CONSTRAINT `bicicletta_ibfk_1` FOREIGN KEY (`telaio`) REFERENCES `veicolo` (`telaio`);

--
-- Limiti per la tabella `motocicletta`
--
ALTER TABLE `motocicletta`
ADD CONSTRAINT `motocicletta_ibfk_2` FOREIGN KEY (`codAlimentazione`) REFERENCES `alimentazione` (`codAlimentazione`),
ADD CONSTRAINT `motocicletta_ibfk_3` FOREIGN KEY (`telaio`) REFERENCES `veicolo` (`telaio`);

--
-- Limiti per la tabella `proprieta`
--
ALTER TABLE `proprieta`
ADD CONSTRAINT `proprieta_ibfk_1` FOREIGN KEY (`telaio`) REFERENCES `veicolo` (`telaio`);

--
-- Limiti per la tabella `proprietario`
--
ALTER TABLE `proprietario`
ADD CONSTRAINT `proprietario_ibfk_1` FOREIGN KEY (`idProprietario`) REFERENCES `proprieta` (`idProprietario`);

--
-- Limiti per la tabella `veicolo`
--
ALTER TABLE `veicolo`
ADD CONSTRAINT `veicolo_ibfk_1` FOREIGN KEY (`codveicolo`) REFERENCES `catveicolo` (`codVeicolo`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
